using System.Globalization;
using System.Text;
using Microsoft.Extensions.Logging;
using CulinaryBlog.Application.Common.Exceptions;
using CulinaryBlog.Application.Common.Interfaces;
using CulinaryBlog.Application.Common.Observability;
using CulinaryBlog.Application.Common.Validation;
using CulinaryBlog.Application.DTOs.Recipes;
using CulinaryBlog.Domain.Entities;
using CulinaryBlog.Domain.Enums;
using CulinaryBlog.Domain.Interfaces;
using MediatR;
using BusinessRuleException = CulinaryBlog.Domain.Exceptions.BusinessRuleException;

namespace CulinaryBlog.Application.Features.Recipes.Commands;

public sealed class RecipeCommandHandler :
    IRequestHandler<CreateRecipeCommand, RecipeMutationResult>,
    IRequestHandler<UpdateRecipeCommand, RecipeMutationResult>,
    IRequestHandler<SetRecipeStatusCommand, RecipeMutationResult>,
    IRequestHandler<DeleteRecipeCommand, RecipeMutationResult>,
    IRequestHandler<AddRecipeIngredientCommand, Guid>,
    IRequestHandler<UpdateRecipeIngredientCommand>,
    IRequestHandler<DeleteRecipeIngredientCommand>,
    IRequestHandler<AddRecipeStepCommand, Guid>,
    IRequestHandler<UpdateRecipeStepCommand>,
    IRequestHandler<DeleteRecipeStepCommand>,
    IRequestHandler<ReorderRecipeStepsCommand>,
    IRequestHandler<UpdateRecipeImageCommand>,
    IRequestHandler<DeleteRecipeImageCommand>
{
    private readonly IRecipeRepository _recipes;
    private readonly IRepository<Category> _categories;
    private readonly IRepository<Recipe> _recipeStore;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ICurrentUser _currentUser;
    private readonly IImageCleanupJobScheduler _imageCleanupJobs;
    private readonly ILogger<RecipeCommandHandler> _logger;

    public RecipeCommandHandler(
        IRecipeRepository recipes,
        IRepository<Category> categories,
        IRepository<Recipe> recipeStore,
        IUnitOfWork unitOfWork,
        ICurrentUser currentUser,
        IImageCleanupJobScheduler imageCleanupJobs,
        ILogger<RecipeCommandHandler> logger)
    {
        _recipes = recipes;
        _categories = categories;
        _recipeStore = recipeStore;
        _unitOfWork = unitOfWork;
        _currentUser = currentUser;
        _imageCleanupJobs = imageCleanupJobs;
        _logger = logger;
    }

    public async Task<RecipeMutationResult> Handle(
        CreateRecipeCommand request,
        CancellationToken cancellationToken)
    {
        EnsureCanCreateRecipe();
        ValidateRecipeFields(
            request.Title,
            request.Description,
            request.PrepTimeMinutes,
            request.CookTimeMinutes,
            request.Servings,
            request.Difficulty);
        await EnsureCategoryExistsAsync(
            request.CategoryId,
            cancellationToken);

        var ingredients = request.Ingredients
            .Select((item, index) => CreateIngredient(item, index))
            .ToList();
        var steps = request.Steps
            .Select((item, index) => CreateStep(item, index + 1))
            .ToList();
        var slug = await CreateUniqueSlugAsync(
            request.Title,
            cancellationToken);

        var recipe = new Recipe
        {
            Title = request.Title.Trim(),
            Slug = slug,
            Description = request.Description.Trim(),
            Instructions = request.Instructions?.Trim() ?? string.Empty,
            CategoryId = request.CategoryId,
            PrepTimeMinutes = request.PrepTimeMinutes,
            CookTimeMinutes = request.CookTimeMinutes,
            Servings = request.Servings,
            Difficulty = request.Difficulty,
            Status = RecipeStatus.Draft,
            AuthorId = _currentUser.UserId,
            CreatedAt = DateTime.UtcNow,
            Nutrition = ToNutrition(request.Nutrition),
            Ingredients = ingredients,
            Steps = steps
        };

        foreach (var ingredient in ingredients)
        {
            ingredient.Recipe = recipe;
        }

        foreach (var step in steps)
        {
            step.Recipe = recipe;
        }

        await _recipeStore.AddAsync(recipe, cancellationToken);
        await _unitOfWork.SaveChangesAsync(cancellationToken);
        RecipeMetrics.RecordCreated();
        _logger.LogInformation(
            "Recipe {RecipeId} created by user {UserId} with status {Status}.",
            recipe.Id,
            _currentUser.UserId,
            RecipeStatus.Draft);

        return new RecipeMutationResult(recipe.Id, recipe.Slug);
    }

    public async Task<RecipeMutationResult> Handle(
        UpdateRecipeCommand request,
        CancellationToken cancellationToken)
    {
        var recipe = await GetEditableRecipeAsync(
            request.RecipeId,
            cancellationToken);

        if (recipe.RowVersion != request.RowVersion)
        {
            throw new BusinessRuleException(
                "The recipe was modified by another request. Reload it and try again.");
        }

        ValidateRecipeFields(
            request.Title,
            request.Description,
            request.PrepTimeMinutes,
            request.CookTimeMinutes,
            request.Servings,
            request.Difficulty);
        await EnsureCategoryExistsAsync(
            request.CategoryId,
            cancellationToken);

        var nutrition = request.Nutrition == null
            ? recipe.Nutrition
            : ToNutrition(request.Nutrition);

        recipe.Title = request.Title.Trim();
        recipe.Description = request.Description.Trim();
        recipe.Instructions = request.Instructions?.Trim() ?? string.Empty;
        recipe.CategoryId = request.CategoryId;
        recipe.PrepTimeMinutes = request.PrepTimeMinutes;
        recipe.CookTimeMinutes = request.CookTimeMinutes;
        recipe.Servings = request.Servings;
        recipe.Difficulty = request.Difficulty;
        recipe.Nutrition = nutrition;
        recipe.UpdatedAt = DateTime.UtcNow;

        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return new RecipeMutationResult(recipe.Id, recipe.Slug);
    }

    public async Task<RecipeMutationResult> Handle(
        SetRecipeStatusCommand request,
        CancellationToken cancellationToken)
    {
        var recipe = await GetOwnedRecipeAsync(
            request.RecipeId,
            cancellationToken);

        if (recipe.Status == request.Status)
        {
            return new RecipeMutationResult(recipe.Id, recipe.Slug);
        }

        if (request.Status == RecipeStatus.Published)
        {
            recipe.Publish();
        }
        else if (request.Status == RecipeStatus.Draft)
        {
            recipe.Unpublish();
        }
        else if (request.Status == RecipeStatus.Archived)
        {
            recipe.Archive();
        }
        else
        {
            throw new ValidationException("Recipe status is invalid.");
        }

        await _unitOfWork.SaveChangesAsync(cancellationToken);
        if (request.Status == RecipeStatus.Published)
            RecipeMetrics.RecordPublished();
        _logger.LogInformation(
            "Recipe {RecipeId} status changed to {Status} by user {UserId}.",
            recipe.Id,
            request.Status,
            _currentUser.UserId);
        return new RecipeMutationResult(recipe.Id, recipe.Slug);
    }

    public async Task<RecipeMutationResult> Handle(
        DeleteRecipeCommand request,
        CancellationToken cancellationToken)
    {
        var recipe = await GetOwnedRecipeAsync(
            request.RecipeId,
            cancellationToken);
        recipe.SoftDelete();
        await _unitOfWork.SaveChangesAsync(cancellationToken);
        return new RecipeMutationResult(recipe.Id, recipe.Slug);
    }

    public async Task<Guid> Handle(
        AddRecipeIngredientCommand request,
        CancellationToken cancellationToken)
    {
        var recipe = await GetEditableRecipeAsync(
            request.RecipeId,
            cancellationToken);
        var ingredient = CreateIngredient(
            new RecipeIngredientInput(
                request.Name,
                request.Quantity,
                request.Unit,
                request.Notes),
            recipe.Ingredients.Count == 0
                ? 0
                : recipe.Ingredients.Max(item => item.OrderIndex) + 1);
        ingredient.Recipe = recipe;
        recipe.Ingredients.Add(ingredient);
        recipe.UpdatedAt = DateTime.UtcNow;
        await _unitOfWork.SaveChangesAsync(cancellationToken);
        return ingredient.Id;
    }

    public async Task Handle(
        UpdateRecipeIngredientCommand request,
        CancellationToken cancellationToken)
    {
        var recipe = await GetEditableRecipeAsync(
            request.RecipeId,
            cancellationToken);
        var ingredient = recipe.Ingredients
            .FirstOrDefault(item => item.Id == request.IngredientId)
            ?? throw new NotFoundException("Recipe ingredient was not found.");
        ValidateIngredient(request.Name, request.Quantity, request.Unit, request.Notes);

        ingredient.Name = request.Name.Trim();
        ingredient.Quantity = request.Quantity?.Trim();
        ingredient.Unit = request.Unit?.Trim();
        ingredient.Notes = request.Notes?.Trim();
        recipe.UpdatedAt = DateTime.UtcNow;
        await _unitOfWork.SaveChangesAsync(cancellationToken);
    }

    public async Task Handle(
        DeleteRecipeIngredientCommand request,
        CancellationToken cancellationToken)
    {
        var recipe = await GetEditableRecipeAsync(
            request.RecipeId,
            cancellationToken);
        var ingredient = recipe.Ingredients
            .FirstOrDefault(item => item.Id == request.IngredientId)
            ?? throw new NotFoundException("Recipe ingredient was not found.");
        recipe.Ingredients.Remove(ingredient);
        var remainingIngredients = recipe.Ingredients
            .OrderBy(item => item.OrderIndex)
            .ToList();
        for (var index = 0; index < remainingIngredients.Count; index++)
        {
            remainingIngredients[index].OrderIndex = index;
        }

        recipe.UpdatedAt = DateTime.UtcNow;
        await _unitOfWork.SaveChangesAsync(cancellationToken);
    }

    public async Task<Guid> Handle(
        AddRecipeStepCommand request,
        CancellationToken cancellationToken)
    {
        var recipe = await GetEditableRecipeAsync(
            request.RecipeId,
            cancellationToken);
        var step = CreateStep(
            new RecipeStepInput(
                request.Title,
                request.Description,
                request.TimerMinutes,
                request.ImageUrl),
            recipe.Steps.Count == 0
                ? 1
                : recipe.Steps.Max(item => item.StepNumber) + 1);
        step.Recipe = recipe;
        recipe.Steps.Add(step);
        recipe.UpdatedAt = DateTime.UtcNow;
        await _unitOfWork.ExecuteInTransactionAsync(
            async transactionToken =>
            {
                await _unitOfWork.SaveChangesAsync(transactionToken);
                await NormalizeStepNumbersAsync(recipe, transactionToken);
            },
            cancellationToken);
        return step.Id;
    }

    public async Task Handle(
        UpdateRecipeStepCommand request,
        CancellationToken cancellationToken)
    {
        var recipe = await GetEditableRecipeAsync(
            request.RecipeId,
            cancellationToken);
        var step = recipe.Steps
            .FirstOrDefault(item => item.Id == request.StepId)
            ?? throw new NotFoundException("Recipe step was not found.");
        ValidateStep(request.Title, request.Description, request.TimerMinutes, request.ImageUrl);

        await _unitOfWork.ExecuteInTransactionAsync(
            async transactionToken =>
            {
                step.Title = request.Title?.Trim() ?? string.Empty;
                step.Description = request.Description.Trim();
                step.TimerMinutes = request.TimerMinutes;
                step.ImageUrl = request.ImageUrl?.Trim();
                recipe.UpdatedAt = DateTime.UtcNow;
                await _unitOfWork.SaveChangesAsync(transactionToken);
                await NormalizeStepNumbersAsync(recipe, transactionToken);
            },
            cancellationToken);
    }

    public async Task Handle(
        DeleteRecipeStepCommand request,
        CancellationToken cancellationToken)
    {
        var recipe = await GetEditableRecipeAsync(
            request.RecipeId,
            cancellationToken);
        var step = recipe.Steps
            .FirstOrDefault(item => item.Id == request.StepId)
            ?? throw new NotFoundException("Recipe step was not found.");
        EnsurePublishedRecipeKeepsOneStep(recipe, recipe.Steps.Count);

        recipe.Steps.Remove(step);
        var remainingSteps = recipe.Steps
            .OrderBy(item => item.StepNumber)
            .ToList();
        recipe.UpdatedAt = DateTime.UtcNow;
        await _unitOfWork.ExecuteInTransactionAsync(
            async transactionToken =>
            {
                if (remainingSteps.Count == 0)
                {
                    await _unitOfWork.SaveChangesAsync(transactionToken);
                    return;
                }

                SetTemporaryStepNumbers(remainingSteps);
                await _unitOfWork.SaveChangesAsync(transactionToken);
                SetSequentialStepNumbers(remainingSteps);
                await _unitOfWork.SaveChangesAsync(transactionToken);
            },
            cancellationToken);
    }

    public async Task Handle(
        ReorderRecipeStepsCommand request,
        CancellationToken cancellationToken)
    {
        var recipe = await GetEditableRecipeAsync(
            request.RecipeId,
            cancellationToken);
        var stepsById = recipe.Steps.ToDictionary(step => step.Id);
        if (request.StepIds is null
            || request.StepIds.Count != stepsById.Count
            || request.StepIds.Distinct().Count() != request.StepIds.Count
            || request.StepIds.Any(stepId => !stepsById.ContainsKey(stepId)))
        {
            throw new ValidationException(
                "stepIds must contain every recipe step exactly once.");
        }

        var orderedSteps = request.StepIds
            .Select(stepId => stepsById[stepId])
            .ToList();
        if (orderedSteps.Select((step, index) => step.StepNumber == index + 1).All(isOrdered => isOrdered))
        {
            return;
        }

        recipe.UpdatedAt = DateTime.UtcNow;
        await _unitOfWork.ExecuteInTransactionAsync(
            async transactionToken =>
            {
                SetTemporaryStepNumbers(orderedSteps);
                await _unitOfWork.SaveChangesAsync(transactionToken);
                SetSequentialStepNumbers(orderedSteps);
                await _unitOfWork.SaveChangesAsync(transactionToken);
            },
            cancellationToken);
    }

    public async Task Handle(
        UpdateRecipeImageCommand request,
        CancellationToken cancellationToken)
    {
        var recipe = await GetEditableRecipeAsync(
            request.RecipeId,
            cancellationToken);
        var image = recipe.Images
            .FirstOrDefault(item => item.Id == request.ImageId)
            ?? throw new NotFoundException("Recipe image was not found.");

        if (request.IsPrimary == false && image.IsPrimary)
        {
            throw new ValidationException(
                "Select another primary image before unsetting the current one.");
        }

        image.AltText = request.AltText?.Trim();
        if (request.IsPrimary == true)
        {
            foreach (var recipeImage in recipe.Images)
            {
                recipeImage.IsPrimary = recipeImage.Id == image.Id;
            }
        }

        recipe.UpdatedAt = DateTime.UtcNow;
        await _unitOfWork.SaveChangesAsync(cancellationToken);
    }

    public async Task Handle(
        DeleteRecipeImageCommand request,
        CancellationToken cancellationToken)
    {
        var recipe = await GetEditableRecipeAsync(
            request.RecipeId,
            cancellationToken);
        var image = recipe.Images
            .FirstOrDefault(item => item.Id == request.ImageId)
            ?? throw new NotFoundException("Recipe image was not found.");
        var wasPrimary = image.IsPrimary;
        var filesToDelete = new[]
            {
                image.OriginalUrl,
                image.MediumUrl,
                image.ThumbnailUrl
            }
            .Where(url => !string.IsNullOrWhiteSpace(url))
            .Select(url => url!)
            .ToArray();
        recipe.Images.Remove(image);

        if (wasPrimary)
        {
            var replacement = recipe.Images
                .OrderBy(item => item.OrderIndex)
                .FirstOrDefault();
            if (replacement != null)
            {
                replacement.IsPrimary = true;
            }
        }

        recipe.UpdatedAt = DateTime.UtcNow;
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        foreach (var fileUrl in filesToDelete)
        {
            try
            {
                _imageCleanupJobs.Enqueue(fileUrl);
            }
            catch (Exception exception)
            {
                _logger.LogError(
                    exception,
                    "Could not enqueue cleanup for recipe image file {FileUrl}.",
                    fileUrl);
            }
        }
    }

    private async Task<Recipe> GetOwnedRecipeAsync(
        Guid recipeId,
        CancellationToken cancellationToken)
    {
        var recipe = await _recipes.GetByIdWithDetailsAsync(
            recipeId,
            cancellationToken)
            ?? throw new NotFoundException("Recipe was not found.");

        if (!_currentUser.IsAuthenticated
            || !_currentUser.UserId.HasValue
            || recipe.AuthorId != _currentUser.UserId)
        {
            throw new ForbiddenException(
                "You do not have permission to modify this recipe.");
        }

        return recipe;
    }

    private async Task<Recipe> GetEditableRecipeAsync(
        Guid recipeId,
        CancellationToken cancellationToken)
    {
        var recipe = await _recipes.GetByIdWithDetailsAsync(
            recipeId,
            cancellationToken)
            ?? throw new NotFoundException("Recipe was not found.");
        var isOwner = _currentUser.UserId.HasValue
            && recipe.AuthorId == _currentUser.UserId;
        var adminCanEditPublished = _currentUser.IsAdmin
            && recipe.Status == RecipeStatus.Published;

        if (!_currentUser.IsAuthenticated
            || (!isOwner && !adminCanEditPublished))
        {
            throw new ForbiddenException(
                "You can edit only your own recipes or, as an administrator, another author's published recipe.");
        }

        return recipe;
    }

    private async Task EnsureCategoryExistsAsync(
        Guid categoryId,
        CancellationToken cancellationToken)
    {
        if (await _categories.GetByIdAsync(categoryId, cancellationToken) == null)
        {
            throw new ValidationException(
                "Recipe category was not found.");
        }
    }

    private async Task<string> CreateUniqueSlugAsync(
        string title,
        CancellationToken cancellationToken)
    {
        var baseSlug = Slugify(title);
        if (string.IsNullOrWhiteSpace(baseSlug))
        {
            throw new ValidationException("title must contain letters or numbers.");
        }

        var slug = baseSlug;
        var suffix = 2;
        while (await _recipes.SlugExistsAsync(slug, cancellationToken: cancellationToken))
        {
            slug = $"{baseSlug}-{suffix++}";
        }

        return slug;
    }

    private static string Slugify(string value)
    {
        var normalized = value
            .Trim()
            .ToLowerInvariant()
            .Normalize(NormalizationForm.FormD);
        var slug = new StringBuilder();

        foreach (var character in normalized)
        {
            if (CharUnicodeInfo.GetUnicodeCategory(character)
                == UnicodeCategory.NonSpacingMark)
            {
                continue;
            }

            if (char.IsLetterOrDigit(character))
            {
                slug.Append(character);
            }
            else if (slug.Length > 0 && slug[^1] != '-')
            {
                slug.Append('-');
            }
        }

        return slug.ToString().Trim('-');
    }

    private static void ValidateRecipeFields(
        string title,
        string description,
        int prepTimeMinutes,
        int cookTimeMinutes,
        int servings,
        DifficultyLevel difficulty)
    {
        if (string.IsNullOrWhiteSpace(title) || title.Trim().Length > 200)
        {
            throw new ValidationException("title is required and must be at most 200 characters.");
        }

        if (string.IsNullOrWhiteSpace(description))
        {
            throw new ValidationException("description is required.");
        }

        if (prepTimeMinutes <= 0 || cookTimeMinutes < 0 || servings <= 0)
        {
            throw new ValidationException(
                "prepTimeMinutes must be positive; cookTimeMinutes must be non-negative; servings must be positive.");
        }

        if (!Enum.IsDefined(difficulty))
        {
            throw new ValidationException("difficulty is invalid.");
        }
    }

    private static RecipeIngredient CreateIngredient(
        RecipeIngredientInput input,
        int orderIndex)
    {
        ValidateIngredient(input.Name, input.Quantity, input.Unit, input.Notes);
        return new RecipeIngredient
        {
            Name = input.Name.Trim(),
            Quantity = input.Quantity?.Trim(),
            Unit = input.Unit?.Trim(),
            Notes = input.Notes?.Trim(),
            OrderIndex = orderIndex,
            CreatedAt = DateTime.UtcNow
        };
    }

    private static void ValidateIngredient(
        string name,
        string? quantity,
        string? unit,
        string? notes)
    {
        RecipeIngredientQuantityValidator.Validate(quantity);

        if (string.IsNullOrWhiteSpace(name) || name.Trim().Length > 200)
        {
            throw new ValidationException("ingredient name is required and must be at most 200 characters.");
        }

        if (quantity?.Trim().Length > 50
            || unit?.Trim().Length > 50
            || notes?.Trim().Length > 500)
        {
            throw new ValidationException(
                "ingredient quantity and unit must be at most 50 characters; notes must be at most 500 characters.");
        }

    }

    private static RecipeStep CreateStep(
        RecipeStepInput input,
        int stepNumber)
    {
        ValidateStep(input.Title, input.Description, input.TimerMinutes, input.ImageUrl);
        return new RecipeStep
        {
            StepNumber = stepNumber,
            Title = input.Title?.Trim() ?? string.Empty,
            Description = input.Description.Trim(),
            TimerMinutes = input.TimerMinutes,
            ImageUrl = input.ImageUrl?.Trim(),
            CreatedAt = DateTime.UtcNow
        };
    }

    private static void ValidateStep(
        string? title,
        string description,
        int? timerMinutes,
        string? imageUrl)
    {
        if (title?.Trim().Length > 200)
        {
            throw new ValidationException(
                "step title must be at most 200 characters.");
        }

        if (string.IsNullOrWhiteSpace(description))
        {
            throw new ValidationException("step description is required.");
        }

        if (description.Trim().Length > 2000)
        {
            throw new ValidationException(
                "step description must be at most 2000 characters.");
        }

        if (timerMinutes < 0)
        {
            throw new ValidationException("timerMinutes must be non-negative.");
        }

        if (imageUrl?.Trim().Length > 500)
        {
            throw new ValidationException(
                "step imageUrl must be at most 500 characters.");
        }
    }

    private static RecipeNutrition? ToNutrition(RecipeNutritionDto? dto)
    {
        if (dto == null)
        {
            return null;
        }

        var values = new[]
        {
            dto.Calories,
            dto.Protein,
            dto.Carbs,
            dto.Fat,
            dto.Fiber,
            dto.Sodium
        };

        if (values.Any(value => value < 0))
        {
            throw new ValidationException("Nutrition values must be non-negative.");
        }

        if (values.Any(value => value > 99999999.99m))
        {
            throw new ValidationException(
                "Nutrition values exceed the supported precision.");
        }

        return new RecipeNutrition
        {
            Calories = dto.Calories,
            Protein = dto.Protein,
            Carbs = dto.Carbs,
            Fat = dto.Fat,
            Fiber = dto.Fiber,
            Sodium = dto.Sodium
        };
    }

    private void EnsureSignedIn()
    {
        if (!_currentUser.IsAuthenticated)
        {
            throw new ForbiddenException("Sign in to manage recipes.");
        }
    }

    private void EnsureCanCreateRecipe()
    {
        if (!_currentUser.IsAuthenticated || !_currentUser.UserId.HasValue)
        {
            throw new ForbiddenException("Sign in to manage recipes.");
        }

        if (!_currentUser.IsAuthor && !_currentUser.IsAdmin)
        {
            throw new ForbiddenException(
                "Only authors and administrators can create recipes.");
        }
    }

    private static void EnsurePublishedRecipeKeepsOneStep(
        Recipe recipe,
        int itemCount)
    {
        if (recipe.Status == RecipeStatus.Published && itemCount <= 1)
        {
            throw new ValidationException(
                "A published recipe must keep at least one step.");
        }
    }

    private async Task NormalizeStepNumbersAsync(
        Recipe recipe,
        CancellationToken cancellationToken)
    {
        var steps = recipe.Steps
            .OrderBy(step => step.StepNumber)
            .ToList();
        if (steps.Select((step, index) => step.StepNumber == index + 1).All(isOrdered => isOrdered))
        {
            return;
        }

        SetTemporaryStepNumbers(steps);
        await _unitOfWork.SaveChangesAsync(cancellationToken);
        SetSequentialStepNumbers(steps);
        await _unitOfWork.SaveChangesAsync(cancellationToken);
    }

    private static void SetTemporaryStepNumbers(
        IReadOnlyList<RecipeStep> steps)
    {
        for (var index = 0; index < steps.Count; index++)
        {
            steps[index].StepNumber = -(index + 1);
        }
    }

    private static void SetSequentialStepNumbers(
        IReadOnlyList<RecipeStep> steps)
    {
        for (var index = 0; index < steps.Count; index++)
        {
            steps[index].StepNumber = index + 1;
        }
    }
}
